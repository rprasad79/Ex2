package assignment2;

import edu.utexas.cs.sam.io.SamTokenizer;
import edu.utexas.cs.sam.io.Tokenizer;
import edu.utexas.cs.sam.io.Tokenizer.TokenType;

import java.io.IOException;

public class LiveOak2Compiler
{
	public static void main(String[] args) throws IOException {
		if (args.length != 2) {
			throw new Error("Expected 2 arguments: source file and output SaM file");
		}
		String inputFile = args[0];
		String outputFile = args[1];

		//TODO: call compiler, write SaM code to file...
		
	}

	static String compiler(String fileName) 
	{
		//returns SaM code for program in file
		try 
		{
			SamTokenizer f = new SamTokenizer(fileName, SamTokenizer.TokenizerOptions.PROCESS_STRINGS);
			String pgm = getProgram(f);
			return pgm;
		} 
		catch (Exception | Error e) {
		{
			// Note: if running on Windows for local grader, may need to modify filename
			// with something like this:
			// fileName.replace('\\', '/');

			// The grader expects this message on compilation failure.
			System.err.println("Failed to compile " + fileName);
			throw new Error(e);
		}
	}

	static String getProgram(SamTokenizer f)
	{
		// TODO: compile the complete program.
		// When detecting a syntax or other compilation error anywhere in the compiler,
		// throw an Error with a useful message indicating what went wrong.
		
		String pgm="";
		while(f.peekAtKind()!=TokenType.EOF)
		{
			pgm+= getMethod(f);
		}
		return pgm;

	}
	static String getMethod(SamTokenizer f)
	{
		//TODO: add code to convert a method declaration to SaM code.
		f.check("int"); //must match at begining
		String methodName = f.getString(); 
		f.check ("("); // must be an opening parenthesis
		String formals = getFormals(f);
		f.check(")");  // must be an closing parenthesis
		//You would need to read in formals if any
		//And then have calls to getDeclarations and getStatements.
		return null;
	}

	static String getExp(SamTokenizer f) 
	{
			  switch (f.peekAtKind()) {
				 case INTEGER: //E -> integer
					return "PUSHIMM " + f.getInt() + "\n";
				 case OPERATOR:  
				 {
				 }
				 default:
					// Simple example: provide a more informative error message when possible
					throw new Error("Invalid expression.");
			  }
	}

	static String getFormals(SamTokenizer f){
			return null;
	}
}
