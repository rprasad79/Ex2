package assignment2;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

// NOTE: if your SaM jar uses the older package name, change these three imports to edu.cornell.cs.sam.io.*
import edu.utexas.cs.sam.io.SamTokenizer;
import edu.utexas.cs.sam.io.Tokenizer.TokenType;
import edu.utexas.cs.sam.io.TokenizerException;

/**
 * LiveOak-2 to SaM compiler: a handwritten recursive-descent parser that type-checks
 * and generates SaM code in a single pass (after a signature pre-pass so that methods
 * may be called before they are defined).
 *
 * Usage: java -jar compiler.jar input.lo output.sam
 */
public class LiveOak2Compiler {

    /** The grammar says '=' on bools is not legal; flip to true to accept it. */
    private static final boolean ALLOW_BOOL_EQUALITY = false;

    private static final Set<String> KEYWORDS = new HashSet<>(java.util.Arrays.asList(
        "int", "bool", "String", "true", "false", "return", "if", "else", "while", "break"));

    private static final class MethodInfo {
        final String name; final Type ret; final List<Type> params; final String label;
        MethodInfo(String name, Type ret, List<Type> params) {
            this.name = name; this.ret = ret; this.params = params; this.label = "M_" + name;
        }
    }

    // ------------------------------------------------------------------ driver

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java -jar compiler.jar <input.lo> <output.sam>");
            System.exit(2);
        }
        String code;
        try {
            code = compile(args[0]);
        } catch (CompileError e) {
            fail(args[1], "Compile error: " + e.getMessage());
            return;
        } catch (TokenizerException e) {
            fail(args[1], "Compile error: lexical/syntax error near line " + e.getLine() + ": " + e.getMessage());
            return;
        } catch (IOException e) {
            fail(args[1], "I/O error: " + e.getMessage());
            return;
        } catch (RuntimeException e) {
            fail(args[1], "Compile error: " + e);
            return;
        }
        try {
            Files.write(new File(args[1]).toPath(), code.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("I/O error: " + e.getMessage());
            System.exit(2);
        }
    }

    private static void fail(String outFile, String msg) {
        System.err.println(msg);
        new File(outFile).delete();      // never leave a stale/partial SaM file behind
        System.exit(1);
    }

    /** Compile a LiveOak-2 source file and return the SaM program text. */
    public static String compile(String fileName) throws IOException {
        LiveOak2Compiler c = new LiveOak2Compiler(fileName);
        return c.run();
    }

    // ------------------------------------------------------------------ state

    private final String fileName;
    private SamTokenizer tz;
    private final Map<String, MethodInfo> methods = new HashMap<>();
    private final StringBuilder out = new StringBuilder();
    private int labelCount = 0;

    private MethodInfo curMethod;
    private SymbolTable curSym;
    private final Deque<String> loopEnds = new ArrayDeque<>();

    private boolean usesConcat, usesRepeat, usesReverse, usesCmp;

    private LiveOak2Compiler(String fileName) { this.fileName = fileName; }

    private SamTokenizer open() throws IOException {
        return new SamTokenizer(fileName, SamTokenizer.TokenizerOptions.PROCESS_STRINGS);
    }

    private String run() throws IOException {
        // Pass 1: collect method signatures.
        tz = open();
        scanSignatures();
        tz.close();
        MethodInfo main = methods.get("main");
        if (main == null) throw new CompileError("no main method defined");
        if (!main.params.isEmpty()) throw new CompileError("main must not take any arguments");

        // Pass 2: parse, check, generate.
        tz = open();
        emit("PUSHIMM 0");               // slot for main's return value
        emit("JSR " + main.label);
        emit("STOP");                    // exit status = value on top of stack
        while (peek() != TokenType.EOF) parseMethod();
        tz.close();

        if (usesConcat || usesRepeat || usesReverse) out.append(SaMRuntime.STRLEN);
        if (usesConcat) out.append(SaMRuntime.CONCAT);
        if (usesRepeat) out.append(SaMRuntime.REPEAT);
        if (usesReverse) out.append(SaMRuntime.REVERSE);
        if (usesCmp) out.append(SaMRuntime.CMP);
        emit("STOP");                    // never reached; keeps trailing labels valid
        return out.toString();
    }

    // ------------------------------------------------------------------ token helpers

    private TokenType peek() {
        TokenType k = tz.peekAtKind();
        while (k == TokenType.COMMENT) { tz.skipToken(); k = tz.peekAtKind(); }
        return k;
    }

    private boolean isOp(char c) { peek(); return tz.test(c); }
    private boolean checkOp(char c) { peek(); return tz.check(c); }
    private boolean isWord(String w) { peek(); return tz.test(w); }

    private void expectOp(char c) {
        if (!checkOp(c)) throw error("expected '" + c + "' but found " + describeNext());
    }

    private void expectWord(String w) {
        peek();
        if (!tz.check(w)) throw error("expected '" + w + "' but found " + describeNext());
    }

    private String describeNext() {
        TokenType k = peek();
        try {
            switch (k) {
                case EOF: return "end of file";
                case WORD: { String w = tz.getWord(); tz.pushBack(); return "'" + w + "'"; }
                case OPERATOR: { char c = tz.getOp(); tz.pushBack(); return "'" + c + "'"; }
                case INTEGER: { int v = tz.getInt(); tz.pushBack(); return "number " + v; }
                case STRING: return "a string literal";
                default: return k.toString().toLowerCase();
            }
        } catch (RuntimeException e) {
            return k.toString().toLowerCase();
        }
    }

    private CompileError error(String msg) {
        int line;
        try { line = tz.nextLineNo(); } catch (RuntimeException e) { line = -1; }
        return new CompileError((line > 0 ? "line " + line + ": " : "") + msg);
    }

    private String parseIdentifier(String what) {
        if (peek() != TokenType.WORD) throw error("expected " + what + " but found " + describeNext());
        String w = tz.getWord();
        if (KEYWORDS.contains(w)) { tz.pushBack(); throw error("'" + w + "' is a keyword and cannot be used as " + what); }
        return w;
    }

    private Type parseType() {
        if (peek() == TokenType.WORD) {
            String w = tz.getWord();
            Type t = Type.fromKeyword(w);
            if (t != null) return t;
            tz.pushBack();
        }
        throw error("expected a type (int, bool, String) but found " + describeNext());
    }

    private boolean atTypeKeyword() { return isWord("int") || isWord("bool") || isWord("String"); }

    // ------------------------------------------------------------------ code emission

    private void emit(String line) { out.append(line).append('\n'); }
    private String newLabel() { return "L" + (labelCount++); }
    private void emitLabel(String l) { out.append(l).append(":\n"); }

    private static String escape(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '"': sb.append("\\\""); break;
                case '\n': sb.append("\\n"); break;
                case '\t': sb.append("\\t"); break;
                case '\r': sb.append("\\r"); break;
                default:
                    if (c < 32 || c > 126) sb.append(String.format("\\%03o", (int) c & 0xFF));
                    else sb.append(c);
            }
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ pass 1

    /** Reads every method header and skips its body, filling the method table. */
    private void scanSignatures() {
        while (peek() != TokenType.EOF) {
            Type rt = parseType();
            String name = parseIdentifier("a method name");
            if (methods.containsKey(name)) throw error("method '" + name + "' is declared more than once (no overloading)");
            expectOp('(');
            List<Type> ps = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            if (!isOp(')')) {
                do {
                    ps.add(parseType());
                    String id = parseIdentifier("a parameter name");
                    if (!seen.add(id)) throw error("duplicate parameter '" + id + "'");
                } while (checkOp(','));
            }
            expectOp(')');
            expectOp('{');
            int depth = 1;
            while (depth > 0) {
                TokenType k = peek();
                if (k == TokenType.EOF) throw error("unexpected end of file: missing '}' in method '" + name + "'");
                if (k == TokenType.OPERATOR) {
                    char c = tz.getOp();
                    if (c == '{') depth++; else if (c == '}') depth--;
                } else tz.skipToken();
            }
            methods.put(name, new MethodInfo(name, rt, ps));
        }
    }

    // ------------------------------------------------------------------ pass 2: declarations / statements

    // MethodDecl -> Type MethodName ( (Formals)? ) { Body }
    private void parseMethod() {
        parseType();
        String name = parseIdentifier("a method name");
        curMethod = methods.get(name);
        curSym = new SymbolTable();
        loopEnds.clear();

        expectOp('(');
        if (!isOp(')')) {
            do {
                Type t = parseType();
                curSym.declareParam(parseIdentifier("a parameter name"), t);
            } while (checkOp(','));
        }
        expectOp(')');
        curSym.finishParams();
        expectOp('{');

        // Body -> (VarDecl)* Block
        while (atTypeKeyword()) parseVarDecl();

        emitLabel(curMethod.label);
        emit("LINK");
        if (curSym.numLocals() > 0) emit("ADDSP " + curSym.numLocals());

        parseBlock();
        expectOp('}');
    }

    // VarDecl -> Type Identifier (, Identifier)* ;
    private void parseVarDecl() {
        Type t = parseType();
        do {
            curSym.declareLocal(parseIdentifier("a variable name"), t);
        } while (checkOp(','));
        expectOp(';');
    }

    // Block -> { (Stmt)+ }
    private void parseBlock() {
        expectOp('{');
        if (isOp('}')) throw error("a block must contain at least one statement");
        while (!isOp('}')) parseStmt();
        expectOp('}');
    }

    private void parseStmt() {
        TokenType k = peek();
        if (k == TokenType.OPERATOR) {
            if (checkOp(';')) return;                                  // null statement
            throw error("unexpected " + describeNext() + " at start of statement");
        }
        if (k != TokenType.WORD) throw error("unexpected " + describeNext() + " at start of statement");

        String w = tz.getWord();
        switch (w) {
            case "return": parseReturn(); return;
            case "if": parseIf(); return;
            case "while": parseWhile(); return;
            case "break":
                if (loopEnds.isEmpty()) throw error("'break' used outside of a loop");
                emit("JUMP " + loopEnds.peek());
                expectOp(';');
                return;
            default:
                tz.pushBack();
                parseAssignment();
        }
    }

    private void parseReturn() {
        Type t = parseExpr();
        if (t != curMethod.ret)
            throw error("method '" + curMethod.name + "' must return " + curMethod.ret + " but returns " + t);
        expectOp(';');
        emit("STOREOFF " + curSym.returnSlotOffset());
        if (curSym.numLocals() > 0) emit("ADDSP -" + curSym.numLocals());
        emit("UNLINK");
        emit("RST");
    }

    private void parseIf() {
        expectOp('(');
        Type t = parseExpr();
        if (t != Type.BOOL) throw error("if condition must be bool, found " + t);
        expectOp(')');
        String lElse = newLabel(), lEnd = newLabel();
        emit("NOT");
        emit("JUMPC " + lElse);
        parseBlock();
        emit("JUMP " + lEnd);
        expectWord("else");
        emitLabel(lElse);
        parseBlock();
        emitLabel(lEnd);
    }

    private void parseWhile() {
        expectOp('(');
        String lTop = newLabel(), lEnd = newLabel();
        emitLabel(lTop);
        Type t = parseExpr();
        if (t != Type.BOOL) throw error("while condition must be bool, found " + t);
        expectOp(')');
        emit("NOT");
        emit("JUMPC " + lEnd);
        loopEnds.push(lEnd);
        parseBlock();
        loopEnds.pop();
        emit("JUMP " + lTop);
        emitLabel(lEnd);
    }

    // Stmt -> Var = Expr ;
    private void parseAssignment() {
        String name = parseIdentifier("a variable name");
        SymbolTable.Var v = curSym.lookup(name);
        if (v == null) throw error("undeclared variable '" + name + "'");
        expectOp('=');
        Type t = parseExpr();
        if (t != v.type) throw error("cannot assign " + t + " to variable '" + name + "' of type " + v.type);
        expectOp(';');
        emit("STOREOFF " + v.offset);
    }

    // ------------------------------------------------------------------ expressions (each leaves one value on the stack)

    private Type parseExpr() {
        TokenType k = peek();
        switch (k) {
            case INTEGER:
                emit("PUSHIMM " + tz.getInt());
                return Type.INT;
            case STRING:
                emit("PUSHIMMSTR \"" + escape(tz.getString()) + "\"");
                return Type.STRING;
            case WORD: {
                String w = tz.getWord();
                if (w.equals("true")) { emit("PUSHIMM 1"); return Type.BOOL; }
                if (w.equals("false")) { emit("PUSHIMM 0"); return Type.BOOL; }
                if (KEYWORDS.contains(w)) { tz.pushBack(); throw error("unexpected keyword '" + w + "' in expression"); }
                if (isOp('(')) return parseCall(w);
                SymbolTable.Var v = curSym.lookup(w);
                if (v == null) throw error("undeclared variable '" + w + "'");
                emit("PUSHOFF " + v.offset);
                return v.type;
            }
            case OPERATOR:
                if (isOp('(')) return parseParenExpr();
                throw error("unexpected " + describeNext() + " in expression");
            default:
                throw error("unexpected " + describeNext() + " in expression");
        }
    }

    // Expr -> MethodName ( (Actuals)? )
    private Type parseCall(String name) {
        MethodInfo m = methods.get(name);
        if (m == null) throw error("call to undefined method '" + name + "'");
        expectOp('(');
        emit("ADDSP 1");                                   // return-value slot
        int n = 0;
        if (!isOp(')')) {
            do {
                if (n >= m.params.size())
                    throw error("too many arguments in call to '" + name + "' (expects " + m.params.size() + ")");
                Type t = parseExpr();
                if (t != m.params.get(n))
                    throw error("argument " + (n + 1) + " of '" + name + "' must be " + m.params.get(n) + " but is " + t);
                n++;
            } while (checkOp(','));
        }
        expectOp(')');
        if (n != m.params.size())
            throw error("too few arguments in call to '" + name + "' (expects " + m.params.size() + ", got " + n + ")");
        emit("JSR " + m.label);
        if (n > 0) emit("ADDSP -" + n);
        return m.ret;
    }

    // Expr -> ( Expr ? Expr : Expr ) | ( Expr Binop Expr ) | ( Unop Expr ) | ( Expr )
    private Type parseParenExpr() {
        expectOp('(');

        if (isOp('~') || isOp('!')) {
            char op = tz.getOp();
            Type t = parseExpr();
            expectOp(')');
            if (op == '~') {
                if (t == Type.INT) { emit("PUSHIMM -1"); emit("TIMES"); return Type.INT; }
                if (t == Type.STRING) { usesReverse = true; emit("JSR RT_reverse"); return Type.STRING; }
                throw error("operator '~' cannot be applied to " + t);
            }
            if (t != Type.BOOL) throw error("operator '!' cannot be applied to " + t);
            emit("NOT");
            return Type.BOOL;
        }

        Type left = parseExpr();

        if (checkOp(')')) return left;                      // ( Expr )

        if (checkOp('?')) {                                 // ternary
            if (left != Type.BOOL) throw error("condition of '?:' must be bool, found " + left);
            String lElse = newLabel(), lEnd = newLabel();
            emit("NOT");
            emit("JUMPC " + lElse);
            Type a = parseExpr();
            emit("JUMP " + lEnd);
            expectOp(':');
            emitLabel(lElse);
            Type b = parseExpr();
            emitLabel(lEnd);
            expectOp(')');
            if (a != b) throw error("branches of '?:' have different types (" + a + " and " + b + ")");
            return a;
        }

        // binary operation
        char op;
        Type right;
        if (peek() == TokenType.INTEGER) {
            // The tokenizer reads "-5" as one integer, so "(x -5)" arrives as x, -5.
            int v = tz.getInt();
            if (v > 0) throw error("expected a binary operator but found number " + v);
            op = '-';
            emit("PUSHIMM " + (-v));
            right = Type.INT;
        } else if (peek() == TokenType.OPERATOR) {
            op = tz.getOp();
            if ("+-*/%&|<>=".indexOf(op) < 0) { tz.pushBack(); throw error("'" + op + "' is not a valid binary operator"); }
            String lRhs = null, lEnd = null;
            if (op == '&' || op == '|') {                   // short-circuit evaluation
                if (left != Type.BOOL) throw error("operator '" + op + "' cannot be applied to " + left);
                lRhs = newLabel(); lEnd = newLabel();
                if (op == '&') {
                    emit("JUMPC " + lRhs); emit("PUSHIMM 0"); emit("JUMP " + lEnd); emitLabel(lRhs);
                } else {
                    emit("JUMPC " + lRhs); // lRhs here is the "already true" label
                }
            }
            right = parseExpr();
            if (op == '&' || op == '|') {
                if (right != Type.BOOL) throw error("operator '" + op + "' cannot be applied to bool and " + right);
                if (op == '|') { emit("JUMP " + lEnd); emitLabel(lRhs); emit("PUSHIMM 1"); }
                emitLabel(lEnd);
                expectOp(')');
                return Type.BOOL;
            }
        } else {
            throw error("expected a binary operator but found " + describeNext());
        }
        expectOp(')');
        return applyBinop(op, left, right);
    }

    private Type applyBinop(char op, Type l, Type r) {
        if (l == Type.INT && r == Type.INT) {
            switch (op) {
                case '+': emit("ADD"); return Type.INT;
                case '-': emit("SUB"); return Type.INT;
                case '*': emit("TIMES"); return Type.INT;
                case '/': emit("DIV"); return Type.INT;
                case '%': emit("MOD"); return Type.INT;
                case '<': emit("LESS"); return Type.BOOL;
                case '>': emit("GREATER"); return Type.BOOL;
                case '=': emit("EQUAL"); return Type.BOOL;
                default: break;
            }
        } else if (l == Type.STRING && r == Type.STRING) {
            switch (op) {
                case '+': usesConcat = true; emit("JSR RT_concat"); emit("ADDSP -1"); return Type.STRING;
                case '<': return stringCompare("LESS");
                case '>': return stringCompare("GREATER");
                case '=': return stringCompare("EQUAL");
                default: break;
            }
        } else if (l == Type.STRING && r == Type.INT && op == '*') {
            usesRepeat = true; emit("JSR RT_repeat"); emit("ADDSP -1"); return Type.STRING;
        } else if (l == Type.BOOL && r == Type.BOOL && op == '=' && ALLOW_BOOL_EQUALITY) {
            emit("EQUAL"); return Type.BOOL;
        }
        throw error("operator '" + op + "' cannot be applied to " + l + " and " + r);
    }

    private Type stringCompare(String sam) {
        usesCmp = true;
        emit("JSR RT_cmp"); emit("ADDSP -1");
        emit("PUSHIMM 0"); emit(sam);                       // (cmp result) <op> 0
        return Type.BOOL;
    }
}
